import streamlit as st
import pandas as pd
import market_analysis
import textwrap
import database



from recommendation_engine import generate_recommendations
from llm_service import (
    generate_llm_recommendations,
    generate_llm_mitigation,
    generate_llm_improvements
)

try:
    from langgraph.graph import StateGraph, START, END
    from typing import TypedDict, Any 
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    from typing import TypedDict, Any 


st.set_page_config(page_title="Prediction AI", layout="wide", initial_sidebar_state="collapsed")

if 'has_analyzed' not in st.session_state:
    st.session_state['has_analyzed'] = False


# --- GLOBAL FONT SIZE OVERRIDE ---
st.markdown('''
<style>
    /* Increase base font size for native Streamlit widgets */
    .stTextInput label, .stSelectbox label, .stNumberInput label, .stTextArea label {
        font-size: 18px !important;
    }
    .stTextInput input, .stSelectbox select, .stNumberInput input, .stTextArea textarea {
        font-size: 16px !important;
    }
    .stMarkdown p, .stMarkdown li {
        font-size: 18px !important;
    }
    div[data-testid="stMetricValue"] {
        font-size: 2.2rem !important;
    }
</style>
''', unsafe_allow_html=True)


# Custom CSS to mimic the Mac-style window from the PDF
st.markdown("""
<style>
/* Main container styling to look like a window */
.main .block-container {
border-radius: 12px;
box-shadow: 0 10px 25px rgba(37, 99, 235, 0.1);
padding: 2rem !important;
margin-top: 3rem;
margin-bottom: 3rem;
border: 1px solid #BFDBFE;
}

/* Mac window controls (Red, Yellow, Green dots) */
.mac-controls {
display: flex;
gap: 8px;
margin-bottom: 20px;
}
.mac-dot {
width: 12px;
height: 12px;
border-radius: 50%;
}
.mac-red { background-color: #ff5f56; }
.mac-yellow { background-color: #ffbd2e; }
.mac-green { background-color: #27c93f; }

/* Customizing the tabs to look more like the PDF */
.stTabs [data-baseweb="tab-list"] {
gap: 24px;
border-bottom: 1px solid #e5e7eb;
}
.stTabs [data-baseweb="tab"] {
height: 50px;
white-space: pre-wrap;
background-color: transparent;
border-radius: 4px 4px 0 0;
gap: 1px;
padding-top: 10px;
padding-bottom: 10px;
font-weight: 600;
color: #6b7280;
}
.stTabs [aria-selected="true"] {
color: #111827;
border-bottom: 2px solid #3b82f6;
}

/* Adjusting headers */
h1 {
font-size: 2.2rem !important;
padding-bottom: 0 !important;
}

</style>
""", unsafe_allow_html=True)

# Injecting the Mac dots at the top of the container
st.markdown("""
<h1 style="margin: 0; padding: 0; font-size: 32px; color: #111827; font-weight: 700; font-family: sans-serif; margin-bottom: 14px; margin-top: -16px;">Prediction AI</h1>
<div class="mac-controls">
<div class="mac-dot mac-red"></div>
<div class="mac-dot mac-yellow"></div>
<div class="mac-dot mac-green"></div>
</div>
""", unsafe_allow_html=True)



tab1, tab2, tab3, tab4 = st.tabs(["Project Input", "Risk Assessment", "Recommendations", "Dashboard"])

#M3 langgraph workflow
class M3WorkflowState(TypedDict, total=False):
    project_data: dict
    market_data: dict
    risk_input_data: dict
    risk_score: int
    risk_status: str
    success_probability: int
    swot: dict 
    feasibility_score: int 
    risk_data: list 
    recommendations: dict
    mitigation_results: list
    improvement_results: list 
    final_response: dict 

def analyze_project(state: M3WorkflowState):
    #collect project & market info
    project_data = state.get("project_data", {})
    market_data = market_analysis.get_market_data(
        project_data.get("industry", "Technology"), 
        project_data.get("target_market", ""),
        project_data.get("budget", 0)
    )

    return {
        "project_data": project_data,
        "market_data": market_data
    }

def analyze_risks(state: M3WorkflowState):
    """Node 2: Prepare the risk and feasibility context."""

    return {
        "risk_input_data": state["risk_input_data"],
        "risk_score": state["risk_score"],
        "risk_status": state["risk_status"],
        "success_probability": state["success_probability"],
        "swot": state["swot"],
        "feasibility_score": state["feasibility_score"],
        "risk_data": state["risk_data"]
    }


def generate_recommendation_node(state: M3WorkflowState):
    """Node 3: Generate strategic recommendations using Gemini."""

    baseline_recommendations = generate_recommendations(
        state["project_data"],
        state["risk_input_data"],
        state["swot"],
        state["feasibility_score"]
    )

    llm_recommendations = generate_llm_recommendations(
        project_data=state["project_data"],
        risk_input_data=state["risk_input_data"],
        swot=state["swot"],
        feasibility_score=state["feasibility_score"],
        market_data=state.get("market_data", {}),
        risk_data=state.get("risk_data", []),
        base_recommendations=baseline_recommendations
    )

    return {
        "recommendations": llm_recommendations
    }


def generate_mitigation_node(state: M3WorkflowState):
    """Node 4: Generate risk mitigation strategies using Gemini."""

    baseline_mitigation = generate_mitigation(
        state["risk_data"]
    )

    llm_mitigation = generate_llm_mitigation(
        project_data=state["project_data"],
        risk_data=state["risk_data"],
        risk_input_data=state["risk_input_data"],
        swot=state["swot"],
        feasibility_score=state["feasibility_score"],
        base_mitigation=baseline_mitigation
    )

    return {
        "mitigation_results": llm_mitigation
    }



def generate_improvements_node(state: M3WorkflowState):
    """Node 5: Generate project improvements using Gemini."""

    baseline_improvements = generate_improvements(
        state["project_data"],
        state["risk_input_data"],
        state["swot"],
        state["feasibility_score"],
        market_data=state.get("market_data", {}),
        mitigation_results=state.get("mitigation_results", [])
    )

    llm_improvements = generate_llm_improvements(
        project_data=state["project_data"],
        risk_input_data=state["risk_input_data"],
        swot=state["swot"],
        feasibility_score=state["feasibility_score"],
        market_data=state.get("market_data", {}),
        risk_data=state.get("risk_data", []),
        mitigation_results=state.get("mitigation_results", []),
        base_improvements=baseline_improvements
    )

    return {
        "improvement_results": llm_improvements
    }


def generate_final_response_node(state: M3WorkflowState):
    """Node 6: Combine all M3 outputs into the final strategic response."""

    project = state.get("project_data", {})
    recommendations = state.get("recommendations", {})
    mitigation = state.get("mitigation_results", [])
    improvements = state.get("improvement_results", [])

    final_response = {
        "project_summary": {
            "project_name": project.get("startup_name", "Unknown"),
            "industry": project.get("industry", "Unknown"),
            "business_model": project.get("business_model", "Unknown"),
            "target_market": project.get("target_market", "Unknown"),
            "budget": project.get("budget", 0),
            "description": project.get("project_description", "")
        },

        "risk_summary": {
            "risk_score": state.get("risk_score", 0),
            "risk_status": state.get("risk_status", "UNKNOWN"),
            "success_probability": state.get("success_probability", 0),
            "feasibility_score": state.get("feasibility_score", 0)
        },

        "key_strategic_recommendations": recommendations.get(
            "recommendations", []
        ),

        "risk_based_recommendations": [
            rec for rec in recommendations.get("recommendations", [])
            if rec.get("category") == "Risk"
        ],

        "mitigation_strategies": mitigation,

        "improvement_suggestions": improvements,

        "short_term_action_plan": recommendations.get(
            "short_term_action_plan", []
        ),

        "long_term_action_plan": recommendations.get(
            "long_term_action_plan", []
        ),

        "final_strategic_assessment": (
            recommendations.get(
                "overall_strategic_recommendation",
                "Review the identified risks and implement the highest-priority mitigation actions."
            )
        )
    }

    return {
        "final_response": final_response
    }


def build_m3_workflow():
    """Build the required six-node LangGraph workflow."""

    if not LANGGRAPH_AVAILABLE:
        return None

    workflow = StateGraph(M3WorkflowState)

    workflow.add_node("analyze_project", analyze_project)
    workflow.add_node("analyze_risks", analyze_risks)
    workflow.add_node(
        "generate_recommendations",
        generate_recommendation_node
    )
    workflow.add_node(
        "generate_mitigation",
        generate_mitigation_node
    )
    workflow.add_node(
        "generate_improvements",
        generate_improvements_node
    )
    workflow.add_node(
        "generate_final_response",
        generate_final_response_node
    )

    workflow.add_edge(START, "analyze_project")
    workflow.add_edge("analyze_project", "analyze_risks")
    workflow.add_edge("analyze_risks", "generate_recommendations")
    workflow.add_edge(
        "generate_recommendations",
        "generate_mitigation"
    )
    workflow.add_edge(
        "generate_mitigation",
        "generate_improvements"
    )
    workflow.add_edge(
        "generate_improvements",
        "generate_final_response"
    )
    workflow.add_edge("generate_final_response", END)

    return workflow.compile()



with tab1:
    st.markdown("""
<h1 style="margin: 0; padding: 0; font-size: 32px; color: #111827; font-weight: 700; font-family: sans-serif;">Data Collection & Market Intelligence</h1>
<p style="margin: 4px 0 24px 0; color: #6B7280; font-size: 19px; font-family: sans-serif;">Gather project data and analyze market landscape</p>
""", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)

    with col1:
        st.subheader("Project Submission")
        
        with st.form("project_form"):
            startup_name = st.text_input("Startup/Project Name", key="input_startup_name", placeholder="e.g., TechVenture AI")
            industry = st.selectbox("Industry/Sector", ["Technology", "Healthcare", "Finance", "Education"], index=None, placeholder="Select an industry...", key="input_industry")
            business_model = st.selectbox("Business Model", ["SaaS", "B2B", "B2C", "Marketplace"], index=None, placeholder="Select a business model...", key="input_business_model")
            target_market = st.text_input("Target Market", placeholder="e.g., SMBs", key="input_target_market")
            budget = st.number_input("Budget (USD)", min_value=0.0, value=None, step=10000.0, key="input_budget")
            description = st.text_area("Project Description", placeholder="Brief description of your project idea...", key="input_description")
            
            submitted = st.form_submit_button("Analyze Project")
            
        if submitted:
            project_data = {
                "startup_name": startup_name,
                "industry": industry,
                "business_model": business_model,
                "target_market": target_market,
                "budget": budget,
                "project_description": description
            }

            #this will store the submitted projeect immediately
            st.session_state["project_data"] = project_data
            st.session_state["assessment_saved"] = False
            
            with st.spinner("Generating AI Analysis Results..."):
                try:
                    from llm_service import generate_project_analysis
                    st.session_state['analysis_results'] = generate_project_analysis(project_data)
                except Exception as e:
                    st.error(f"Failed to load AI Engine: {e}")
                    st.session_state['analysis_results'] = None
                    
            st.session_state['has_analyzed'] = True

            #now to save it to postgresql
            try:
                project_id = database.insert_project(project_data)
                st.session_state["project_id"] = project_id
                st.success("Project analyzed successfully.")
            except Exception as error:
                st.warning("Project analysis is available, but the database could not be updated.")
                st.error(f"Database error: {error}")

    with col2:
        st.subheader("Market Analysis")
        if st.session_state.get('has_analyzed', False):
            data = st.session_state['project_data']
            m_data = market_analysis.get_market_data(data['industry'], data['target_market'], data['budget'])
            
            st.write("**Market Size & Growth Rate**")
            
            m1, m2, m3 = st.columns(3)
            m1.metric("TAM", m_data['TAM']['value'], m_data['TAM']['growth'])
            m2.metric("SAM", m_data['SAM']['value'], m_data['SAM']['growth'])
            m3.metric("SOM", m_data['SOM']['value'], m_data['SOM']['growth'])
            
            st.write("**Market Trends (2020-2026)**")
            chart_data = pd.DataFrame(
                [30, 40, 45, 55, 70, 85, 100],
                columns=["Trend"],
                index=["2020", "2021", "2022", "2023", "2024", "2025", "2026"]
            )
            st.bar_chart(chart_data)
            
        else:
            st.info("Submit a project idea on the left to view the market analysis.")

    with col3:
        st.subheader("Competitor Landscape")
        if st.session_state.get('has_analyzed', False):
            data = st.session_state['project_data']
            c_data = market_analysis.get_competitor_data(data['startup_name'], data['industry'], data['business_model'])
            
            for comp in c_data:
                with st.container():
                    st.markdown(f"**{comp['name']}** `{comp['type']}`")
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Market Share", comp['market_share'])
                    c2.metric("Revenue", comp['revenue'])
                    c3.metric("Growth", comp['growth'])
                    st.progress(comp['position'] / 100, text="Market Position")
                    st.divider()
                    
        else:
            st.info("Submit a project idea to generate competitor insights.")

with tab2:
    st.markdown("""
<h1 style="margin: 0; padding: 0; font-size: 32px; color: #111827; font-weight: 700; font-family: sans-serif;">Risk Assessment & SWOT Analysis</h1>
<p style="margin: 4px 0 24px 0; color: #6B7280; font-size: 19px; font-family: sans-serif;">AI-powered risk scoring and strategic evaluation</p>
""", unsafe_allow_html=True)

    data = st.session_state.get('project_data', {})


    st.subheader("Risk Assessment Inputs")

    col1, col2 = st.columns(2)

    with col1:
        market_competition = st.selectbox("Market Competition", ["Low", "Medium", "High"])
        team_expertise = st.selectbox("Team Expertise", ["Low", "Medium", "High"])
        resource_availability = st.selectbox("Resource Availability", ["Limited", "Moderate", "Good"])

    with col2:
        innovation_level = st.selectbox("Innovation Level", ["Low", "Medium", "High"])
        market_research = st.selectbox("Market Research Quality", ["Limited", "Moderate", "Strong"])

    st.subheader("Project Feasibility Inputs")

    col1, col2 = st.columns(2)

    with col1:
        market_opportunity = st.slider("Market Opportunity Score", 0, 100, 50)
        team_capability = st.slider("Team Capability Score", 0, 100, 50)

    with col2:
        competitive_advantage = st.slider("Competitive Advantage Score", 0, 100, 50)
        resource_score = st.slider("Resource Availability Score", 0, 100, 50)



    # Empty State Handling
    if not (st.session_state.get('has_analyzed', False) or 'risk_assessment_data' in st.session_state):
        st.info("💡 Complete project details on the Project Input tab and click 'Analyze Project', or click 'Evaluate Risk' below to generate risk insights.")
        if st.button("Evaluate Risk"):
            st.session_state['has_analyzed'] = True
            st.rerun()

    if st.session_state.get('has_analyzed', False) or 'risk_assessment_data' in st.session_state:
        from risk_engine import calculate_risk, get_risk_status, calculate_success_probability
        from mitigation_engine import generate_mitigation
        from improvement_engine import generate_improvements
        from swot_analysis import generate_swot
        from feasibility import calculate_feasibility
        import market_analysis
        import database
        
        def calculate_risk_and_swot(mc, te, ra, il, mr, mo, tc, ca, rs):
            r_score = calculate_risk(mc, te, ra, il, mr)
            r_status = get_risk_status(r_score)
            s_prob = calculate_success_probability(r_score)
            
            r_data = [
                {
                    "risk_category": "Market",
                    "risk_score": 80 if mc == "High" else 50,
                    "risk_description": "High competitor density",
                    "priority_level": "High" if mc == "High" else "Medium"
                },
                {
                    "risk_category": "Financial",
                    "risk_score": 75 if data.get("budget", 0) < 50000 else 45,
                    "risk_description": "Budget constraints",
                    "priority_level": "High" if data.get("budget", 0) < 50000 else "Medium"
                },
                {
                    "risk_category": "Technical",
                    "risk_score": 80 if te == "Low" else 40,
                    "risk_description": "Limited technical expertise",
                    "priority_level": "High" if te == "Low" else "Medium"
                }
            ]
            
            sw = generate_swot(te, il, mc, ra, mr)
            f_score = calculate_feasibility(mo, tc, ca, rs)
            
            return {
                'risk_score': r_score,
                'risk_status': r_status,
                'success_probability': s_prob,
                'risk_data': r_data,
                'swot': sw,
                'feasibility_score': f_score
            }
            
        # Update state dynamically with current inputs
        st.session_state['risk_assessment_data'] = calculate_risk_and_swot(
            market_competition, team_expertise, resource_availability, 
            innovation_level, market_research, 
            market_opportunity, team_capability, 
            competitive_advantage, resource_score
        )

        st.session_state["current_market_opportunity"] = market_opportunity
        st.session_state["current_team_capability"] = team_capability
        st.session_state["current_competitive_advantage"] = competitive_advantage
        st.session_state["current_resource_score"] = resource_score
        
        # Read dynamically from session state
        results = st.session_state['risk_assessment_data']
        risk_score = results['risk_score']
        risk_status = results['risk_status']
        success_probability = results['success_probability']
        risk_data = results['risk_data']
        swot = results['swot']
        feasibility_score = results['feasibility_score']

        mitigation_results = generate_mitigation(risk_data)
        market_data_for_improvements = market_analysis.get_market_data(
            data.get("industry", "Technology"),
            data.get("target_market", ""),
            data.get("budget", 0),
        )

        from swot_analysis import generate_swot
        swot = generate_swot(team_expertise, innovation_level, market_competition, resource_availability, market_research)

        from feasibility import calculate_feasibility
        feasibility_score = calculate_feasibility(market_opportunity, team_capability, competitive_advantage, resource_score)

        risk_input_data = {
            "market_competition": market_competition,
            "team_expertise": team_expertise,
            "resource_availability": resource_availability,
            "innovation_level": innovation_level,
            "market_research": market_research,
            "risk_score": risk_score
        }

            # ============================================================
            # M3 - STRATEGIC RECOMMENDATIONS
            # ============================================================

        recommendation_results = generate_recommendations(
            data,
            risk_input_data,
            swot,
            feasibility_score
        )

        # ============================================================
        # M3 - IMPROVEMENT PLAN
        # ============================================================

        improvement_results = generate_improvements(
            data,
            risk_input_data,
            swot,
            feasibility_score,
            market_data=market_data_for_improvements,
            mitigation_results=mitigation_results
        )

        project_id = st.session_state.get("project_id")

        if project_id and not st.session_state.get("assessment_saved", False):
            try:
                database.save_assessment(
                    project_id=project_id,
                    swot_data=swot,
                    risk_score=risk_score,
                    risk_status=risk_status,
                    success_probability=success_probability,
                    recommendations=recommendation_results["recommendations"],
                    mitigations=mitigation_results,
                    improvements=improvement_results,
                )

                st.session_state["assessment_saved"] = True

            except Exception as error:
                print(
                    f"Could not save the assessment to the database: {error}"
                )

        # Format SWOT bullets as HTML dots
        def format_swot(items):
            return "".join([f'<div style="margin-bottom:4px;">• {item}</div>' for item in items])
            st.markdown("<br>", unsafe_allow_html=True)

        # ============================================================
        # M2 RESULTS DASHBOARD
        # ============================================================

        st.divider()
        st.subheader("Risk Assessment Results")

        # ------------------------------------------------------------
        # TOP SUMMARY
        # ------------------------------------------------------------

        summary_col1, summary_col2, summary_col3 = st.columns(3)

        with summary_col1:
            st.metric(
                "Overall Risk Score",
                f"{risk_score}/100",
                risk_status
            )

        with summary_col2:
            st.metric(
                "Success Probability",
                f"{success_probability}%"
            )

        with summary_col3:
            st.metric(
                "Feasibility Score",
                f"{feasibility_score}%"
            )

        st.divider()

        # ------------------------------------------------------------
        # MAIN RESULTS AREA
        # LEFT = KEY RISKS
        # RIGHT = SWOT
        # ------------------------------------------------------------

        left_col, right_col = st.columns([1, 2])

        # ============================================================
        # LEFT COLUMN - KEY RISK FACTORS
        # ============================================================

        with left_col:

            st.subheader("Key Risk Factors")

            st.markdown(
                f"""
                **👥 Team Expertise**

                {team_expertise} technical experience
                """
            )

            st.markdown(
                f"""
                **💡 Innovation Level**

                {innovation_level} innovation potential
                """
            )

            st.markdown(
                f"""
                **📊 Market Competition**

                {market_competition} competition
                """
            )

            st.markdown(
                f"""
                **📦 Resource Availability**

                {resource_availability}
                """
            )

            st.markdown(
                f"""
                **🔎 Market Research**

                {market_research}
                """
            )

            # Risk status card
            if risk_status == "HIGH RISK":
                st.error(f"⚠️ **{risk_status}**")
            elif risk_status == "MEDIUM RISK":
                st.warning(f"⚠️ **{risk_status}**")
            else:
                st.success(f"✓ **{risk_status}**")

        # ============================================================
        # RIGHT COLUMN - SWOT
        # ============================================================

        with right_col:

            st.subheader("SWOT Analysis")

            swot_col1, swot_col2 = st.columns(2)

            with swot_col1:

                st.success("### 💪 Strengths")

                for item in swot["Strengths"]:
                    st.markdown(f"- {item}")

                st.info("### 🚀 Opportunities")

                for item in swot["Opportunities"]:
                    st.markdown(f"- {item}")

            with swot_col2:

                st.error("### ⚠️ Weaknesses")

                for item in swot["Weaknesses"]:
                    st.markdown(f"- {item}")

                st.warning("### 🔥 Threats")

                for item in swot["Threats"]:
                    st.markdown(f"- {item}")

        st.divider()

        # ------------------------------------------------------------
        # PROJECT FEASIBILITY
        # ------------------------------------------------------------

        st.subheader("Project Feasibility")

        feasibility_col1, feasibility_col2 = st.columns([1, 2])

        with feasibility_col1:

            st.metric(
                "Feasibility Score",
                f"{feasibility_score}%"
            )

            if feasibility_score >= 70:
                st.success("Good Feasibility")
            elif feasibility_score >= 40:
                st.warning("Moderate Feasibility")
            else:
                st.error("Low Feasibility")

        with feasibility_col2:

            st.write("**Assessment Metrics**")

            st.progress(
                team_capability / 100,
                text=f"Team Capability — {team_capability}%"
            )

            st.progress(
                competitive_advantage / 100,
                text=f"Competitive Advantage — {competitive_advantage}%"
            )

            st.progress(
                resource_score / 100,
                text=f"Resource Availability — {resource_score}%"
            )

            st.progress(
                market_opportunity / 100,
                text=f"Market Opportunity — {market_opportunity}%"
            )


with tab3:
    st.markdown("""
<h1 style="margin: 0; padding: 0; font-size: 32px; color: #111827; font-weight: 700; font-family: sans-serif;">Recommendations & Strategic Reasoning</h1>
<p style="margin: 4px 0 24px 0; color: #6B7280; font-size: 19px; font-family: sans-serif;">AI-powered mitigation strategies and agent workflows</p>
""", unsafe_allow_html=True)

    if not st.session_state.get('has_analyzed', False):
        st.info("💡 Please enter project details and click 'Analyze Project' to view AI Recommendations.")
    else:
        data = st.session_state.get('project_data', {})


        recommendation_tab, risk_mitigation_tab, improvements_tab, langgraph_tab = st.tabs([
            "Strategic Recommendations",
            "Risk Mitigation",
            "Improvements",
            "LangGraph Agent"
        ])

        # ============================================================
        # STRATEGIC RECOMMENDATIONS
        # ============================================================

        with recommendation_tab:

            st.subheader("AI Strategic Recommendations")

            if recommendation_results:

                overall = recommendation_results.get(
                    "overall_strategic_recommendation",
                    "Focus on reducing the highest-priority project risks."
                )

                st.info(overall)

                recommendations = recommendation_results.get(
                    "recommendations",
                    []
                )

                if recommendations:

                    for rec in recommendations:

                        priority = rec.get("priority", "Medium")
                        category = rec.get("category", "Strategy")
                        title = rec.get("title", "Recommendation")

                        st.markdown(
                            f"### {title}"
                        )

                        st.markdown(
                            f"**Category:** {category}  \n"
                            f"**Priority:** {priority}"
                        )

                        st.markdown(
                            f"**Problem:** {rec.get('problem', 'N/A')}"
                        )

                        if rec.get("explanation"):
                            st.markdown(
                                f"**Why it matters:** {rec['explanation']}"
                            )

                        st.markdown(
                            f"**Recommended Action:** "
                            f"{rec.get('action', 'N/A')}"
                        )

                        st.markdown(
                            f"**Risk Reduction:** "
                            f"{rec.get('risk_reduction', 'N/A')}"
                        )

                        st.divider()

                else:
                    st.warning("No strategic recommendations were generated.")

                # Short-term plan
                st.subheader("Short-Term Action Plan")

                short_term = recommendation_results.get(
                "short_term_action_plan",
                []
                )

                for action in short_term:
                    st.markdown(f"- {action}")

                # Long-term plan
                st.subheader("Long-Term Action Plan")

                long_term = recommendation_results.get(
                    "long_term_action_plan",
                    []
                )

                for action in long_term:
                    st.markdown(f"- {action}")

            else:
                st.warning("No strategic recommendations available.")


        with improvements_tab:
            st.markdown("""
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 16px;">
            <h3 style="margin:0; font-size: 20px; color: #111827; font-family: sans-serif;">Improvements</h3>
            <span style="background: #6D28D9; color: white; padding: 2px 8px; border-radius: 12px; font-size: 14px; font-weight: bold; font-family: sans-serif;">AI Powered</span>
            </div>
        <style>
        .improvement-card-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
        margin-bottom: 12px;
        }
        .improvement-flip-card {
        min-height: 238px;
        perspective: 1200px;
        font-family: sans-serif;
        }
        .improvement-flip-inner {
        position: relative;
        width: 100%;
        min-height: 238px;
        transition: transform 0.7s cubic-bezier(.2,.7,.2,1);
        transform-style: preserve-3d;
        }
        .improvement-flip-card:hover .improvement-flip-inner,
        .improvement-flip-card:focus-within .improvement-flip-inner {
        transform: rotateY(180deg);
        }
        .improvement-face {
        position: absolute;
        inset: 0;
        min-height: 238px;
        padding: 16px;
        border: 1px solid rgba(255, 255, 255, 0.72);
        border-radius: 16px;
        box-sizing: border-box;
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
        box-shadow: 0 16px 32px rgba(31, 41, 55, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.8);
        overflow: hidden;
        }
        .improvement-front {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.82), rgba(239, 246, 255, 0.58));
        backdrop-filter: blur(18px) saturate(135%);
        -webkit-backdrop-filter: blur(18px) saturate(135%);
        }
        .improvement-back {
        background: linear-gradient(135deg, rgba(245, 243, 255, 0.94), rgba(224, 242, 254, 0.84));
        backdrop-filter: blur(18px) saturate(135%);
        -webkit-backdrop-filter: blur(18px) saturate(135%);
        transform: rotateY(180deg);
        overflow-y: auto;
        }
        .improvement-face h4 {
        margin: 0 0 10px 0;
        color: #111827;
        font-size: 19px;
        line-height: 1.35;
        }
        .improvement-face p,
        .improvement-face li {
        color: #4B5563;
        font-size: 16px;
        line-height: 1.55;
        }
        .improvement-face ul {
        margin: 6px 0 14px 18px;
        padding: 0;
        }
        .improvement-label {
        color: #6D28D9;
        font-size: 14px;
        font-weight: 700;
        letter-spacing: .04em;
        text-transform: uppercase;
        }
        .improvement-priority {
        float: right;
        color: #6D28D9;
        background: rgba(237, 233, 254, 0.9);
        border: 1px solid rgba(196, 181, 253, 0.7);
        border-radius: 999px;
        padding: 3px 9px;
        font-size: 14px;
        font-weight: 700;
        }
        .improvement-hint {
        margin-top: 16px;
        color: #9CA3AF;
        font-size: 14px;
        }
        @media (max-width: 900px) {
        .improvement-card-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        }
        @media (max-width: 620px) {
        .improvement-card-grid {
            grid-template-columns: 1fr;
        }
        }
        </style>
            """, unsafe_allow_html=True)

            improvement_cards = []
            for rec in improvement_results:
                steps = rec.get("steps") or [rec.get("action", "Review this project area and define a corrective action.")]
                steps_html = "".join(f"<li>{step}</li>" for step in steps)
                recommendation_html = "".join(
                    f"{index}. {step}<br>" for index, step in enumerate(steps, start=1)
                )
                card_html = f"""
        <div class="improvement-flip-card" tabindex="0">
          <div class="improvement-flip-inner">
        <div class="improvement-face improvement-front">
          <span class="improvement-label">{rec["category"]}</span>
          <span class="improvement-priority">{rec["priority"]}</span>
          <h4>{rec["title"]}</h4>
          <div class="improvement-label">Problem</div>
          <p>{rec["problem"]}</p>
        </div>
        <div class="improvement-face improvement-back">
          <div class="improvement-label">Solution Steps</div>
          <ul>{steps_html}</ul>
          <div class="improvement-label">Recommendation</div>
        <p>{recommendation_html}</p>
          <div class="improvement-label">Risk Reduction</div>
          <p>{rec["risk_reduction"]}</p>
        </div>
          </div>
        </div>
        """
                improvement_cards.append(textwrap.dedent(card_html))
            st.markdown(
                '<div class="improvement-card-grid">'
                + "".join(improvement_cards)
                + "</div>",
                unsafe_allow_html=True,
            )
        with risk_mitigation_tab:
            st.markdown("""
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin:0; font-size: 20px; color: #111827; font-family: sans-serif;">Risk Mitigation</h3>
        <span style="color: #6B7280;">&#128116;</span>
        </div>
        <style>
        .risk-card-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
        margin-bottom: 12px;
        }
        .risk-glass-card {
        min-height: 220px;
        padding: 16px;
        box-sizing: border-box;
        border: 1px solid rgba(255, 255, 255, 0.58);
        border-radius: 16px;
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.38), rgba(153, 246, 228, 0.2));
        backdrop-filter: blur(24px) saturate(165%);
        -webkit-backdrop-filter: blur(24px) saturate(165%);
        box-shadow: 0 14px 28px rgba(31, 41, 55, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.72), inset 0 -1px 0 rgba(255, 255, 255, 0.18);
        font-family: sans-serif;
        }
        .risk-glass-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 10px;
        }
        .risk-glass-card-risk {
        color: #DC2626;
        font-size: 16px;
        font-weight: 700;
        line-height: 1.4;
        }
        .risk-glass-card-impact {
        flex-shrink: 0;
        color: #047857;
        background: rgba(209, 250, 229, 0.86);
        border: 1px solid rgba(110, 231, 183, 0.7);
        border-radius: 999px;
        padding: 3px 8px;
        font-size: 14px;
        font-weight: 700;
        }
        .risk-glass-card h4 {
        margin: 0 0 10px 0;
        color: #111827;
        font-size: 17px;
        line-height: 1.4;
        }
        .risk-glass-card p {
        margin: 0 0 8px 0;
        color: #4B5563;
        font-size: 15px;
        line-height: 1.5;
        }
        .risk-glass-card strong {
        color: #374151;
        }
        @media (max-width: 900px) {
        .risk-card-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        }
        @media (max-width: 620px) {
        .risk-card-grid {
            grid-template-columns: 1fr;
        }
        }
        </style>
        """,  unsafe_allow_html=True)

            selected_risk = st.pills(
                "Risk Category", 
                ["All Risks", "Financial", "Market", "Technical"], 
                default="All Risks", 
                label_visibility="collapsed",
                key="selected_risk_category"
            )

            if not selected_risk:
                selected_risk = "All Risks"

            mitigation_cards = []
            for mitigation in mitigation_results:

                category = mitigation["category"]

                # Apply selected category filter
                if selected_risk != "All Risks" and category != selected_risk:
                    continue

                card_html = f"""
        <div class="risk-glass-card">
        <div class="risk-glass-card-header">
            <div class="risk-glass-card-risk">&#9888; {mitigation["risk"]}</div>
            <span class="risk-glass-card-impact">{mitigation["impact"]} Impact</span>
        </div>
        <h4>
            {mitigation["mitigation_strategy"]}
        </h4>
        <p><strong>Preventive Action:</strong> {mitigation["preventive_action"]}</p>
        <p><strong>Contingency Action:</strong> {mitigation["contingency_action"]}</p>
        </div>
        """
                mitigation_cards.append(textwrap.dedent(card_html))
            st.markdown(
                '<div class="risk-card-grid">'
                + "".join(mitigation_cards)
                + "</div>",
                unsafe_allow_html=True,
            )
        with langgraph_tab:
            st.markdown("""
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <h3 style="margin:0; font-size: 20px; color: #111827; font-family: sans-serif;">LangGraph Agent</h3>
        <span style="color: #8B5CF6;">&#9881;</span>
        </div>
        """, unsafe_allow_html=True)


            # ========================================================
            # ACTUAL LANGGRAPH WORKFLOW
            # ========================================================

            run_agent_workflow = st.button(
                "Run LangGraph Agent Workflow",
                use_container_width=True,
                type="primary"
            )

            if run_agent_workflow:

                if not LANGGRAPH_AVAILABLE:
                    st.error(
                        "LangGraph is not installed. "
                        "Install it with: pip install langgraph"
                    )

                else:
                    with st.spinner("Running M3 LangGraph workflow..."):

                        workflow = build_m3_workflow()

                        initial_state = {
                            "project_data": data,
                            "risk_input_data": risk_input_data,
                            "risk_score": risk_score,
                            "risk_status": risk_status,
                            "success_probability": success_probability,
                            "swot": swot,
                            "feasibility_score": feasibility_score,
                            "risk_data": risk_data
                        }

                        workflow_result = workflow.invoke(
                            initial_state
                        )

                        st.session_state["m3_workflow_result"] = workflow_result

                    st.success(
                        "LangGraph workflow completed successfully."
                    )

            # ========================================================
            # FINAL STRATEGIC RESPONSE
            # ========================================================

            workflow_result = st.session_state.get(
                "m3_workflow_result"
            )

            if workflow_result:

                final_response = workflow_result.get(
                    "final_response",
                    {}
                )

                st.divider()
                st.subheader("Final Strategic Response")

                # Project Summary
                st.markdown("### PROJECT SUMMARY")

                project_summary = final_response.get(
                    "project_summary",
                    {}
                )

                st.write(
                    f"**Project:** "
                    f"{project_summary.get('project_name', 'N/A')}"
                )

                st.write(
                    f"**Industry:** "
                    f"{project_summary.get('industry', 'N/A')}"
                )

                st.write(
                    f"**Target Market:** "
                    f"{project_summary.get('target_market', 'N/A')}"
                )

                # Risk Summary
                st.markdown("### RISK SUMMARY")

                risk_summary = final_response.get(
                    "risk_summary",
                    {}
                )

                r1, r2, r3, r4 = st.columns(4)

                r1.metric(
                    "Risk Score",
                    risk_summary.get("risk_score", 0)
                )

                r2.metric(
                    "Risk Status",
                    risk_summary.get("risk_status", "N/A")
                )

                r3.metric(
                    "Success Probability",
                    f"{risk_summary.get('success_probability', 0)}%"
                )

                r4.metric(
                    "Feasibility",
                    f"{risk_summary.get('feasibility_score', 0)}%"
                )

                # Strategic Recommendations
                st.markdown(
                    "### KEY STRATEGIC RECOMMENDATIONS"
                )

                for rec in final_response.get(
                    "key_strategic_recommendations",
                    []
                ):
                    st.markdown(
                        f"**{rec.get('title', 'Recommendation')}** "
                        f"- {rec.get('action', 'N/A')}"
                    )

                # Risk-Based Recommendations
                st.markdown(
                    "### RISK-BASED RECOMMENDATIONS"
                )

                risk_recommendations = final_response.get(
                    "risk_based_recommendations",
                    []
                )

                if risk_recommendations:
                    for rec in risk_recommendations:
                        st.markdown(
                            f"- **{rec.get('title', 'Risk Recommendation')}**: "
                            f"{rec.get('action', 'N/A')}"
                        )
                else:
                    st.write(
                        "No separate risk-category recommendations."
                    )

                # Mitigation
                st.markdown(
                    "### MITIGATION STRATEGIES"
                )

                for mitigation in final_response.get(
                    "mitigation_strategies",
                    []
                ):
                    st.markdown(
                        f"**{mitigation.get('risk', 'Risk')}**"
                    )
                    st.write(
                        mitigation.get(
                            "mitigation_strategy",
                            "N/A"
                        )
                    )

                # Improvements
                st.markdown(
                    "### IMPROVEMENT SUGGESTIONS"
                )

                for improvement in final_response.get(
                    "improvement_suggestions",
                    []
                ):
                    st.markdown(
                        f"**{improvement.get('title', 'Improvement')}** "
                        f"({improvement.get('priority', 'Medium')})"
                    )

                    st.write(
                        improvement.get(
                            "improvement",
                            improvement.get(
                                "risk_reduction",
                                "N/A"
                            )
                        )
                    )

                # Short-Term Plan
                st.markdown(
                    "### SHORT-TERM ACTION PLAN"
                )

                for action in final_response.get(
                    "short_term_action_plan",
                    []
                ):
                    st.markdown(f"- {action}")

                # Long-Term Plan
                st.markdown(
                    "### LONG-TERM ACTION PLAN"
                )

                for action in final_response.get(
                    "long_term_action_plan",
                    []
                ):
                    st.markdown(f"- {action}")

                # Final Assessment
                st.markdown(
                    "### FINAL STRATEGIC ASSESSMENT"
                )

                st.info(
                    final_response.get(
                        "final_strategic_assessment",
                        "No final assessment available."
                    )
                )




# ============================================================
# TAB 4 - DASHBOARD
# ============================================================

with tab4:

    st.markdown("""
    <h1 style="margin: 0; padding: 0; font-size: 32px; color: #111827;
    font-weight: 700; font-family: sans-serif; margin-bottom: 4px;">
    Project Risk Dashboard
    </h1>

    <p style="margin: 0 0 24px 0; color: #6B7280; font-size: 19px;
    font-family: sans-serif;">
    Comprehensive project health, risk analysis and strategic assessment
    </p>
    """, unsafe_allow_html=True)

    # ------------------------------------------------------------
    # EMPTY STATE
    # ------------------------------------------------------------

    if not st.session_state.get("has_analyzed", False):

        st.info(
            "💡 Enter your project details and click "
            "'Analyze Project' to generate the dashboard."
        )

    else:

        # ========================================================
        # LOAD REAL PROJECT DATA
        # ========================================================

        project = st.session_state.get("project_data", {})

        assessment = st.session_state.get(
            "risk_assessment_data",
            {}
        )

        risk_score = assessment.get("risk_score", 0)
        risk_status = assessment.get("risk_status", "UNKNOWN")
        success_probability = assessment.get(
            "success_probability",
            0
        )
        feasibility_score = assessment.get(
            "feasibility_score",
            0
        )

        risk_data = assessment.get(
            "risk_data",
            []
        )

        swot = assessment.get(
            "swot",
            {}
        )

        # M3 outputs generated earlier in Tab 2
        recommendations = locals().get(
            "recommendation_results",
            {}
        )

        mitigation_results = locals().get(
            "mitigation_results",
            []
        )

        improvement_results = locals().get(
            "improvement_results",
            []
        )

        # LangGraph result, if the workflow has been executed
        workflow_result = st.session_state.get(
            "m3_workflow_result",
            {}
        )

        final_response = workflow_result.get(
            "final_response",
            {}
        ) if workflow_result else {}

        # ========================================================
        # PROJECT OVERVIEW
        # ========================================================

        st.subheader("Project Overview")

        overview_col1, overview_col2, overview_col3 = st.columns(3)

        with overview_col1:
            st.markdown(
                f"""
                **Project**

                {project.get("startup_name", "N/A")}

                **Industry**

                {project.get("industry", "N/A")}
                """
            )

        with overview_col2:
            st.markdown(
                f"""
                **Business Model**

                {project.get("business_model", "N/A")}

                **Target Market**

                {project.get("target_market", "N/A")}
                """
            )

        with overview_col3:
            budget = project.get("budget", 0)

            try:
                budget_display = f"${float(budget):,.0f}"
            except (TypeError, ValueError):
                budget_display = str(budget)

            st.markdown(
                f"""
                **Budget**

                {budget_display}

                **Project Status**

                {"Analysis Complete" if st.session_state.get("has_analyzed")
                else "Pending Analysis"}
                """
            )

        description = project.get(
            "project_description",
            ""
        )

        if description:
            st.markdown("**Project Description**")
            st.info(description)

        st.divider()

        # ========================================================
        # TOP RISK SUMMARY
        # ========================================================

        st.subheader("Risk & Project Health")

        metric1, metric2, metric3, metric4 = st.columns(4)

        with metric1:
            st.metric(
                "Overall Risk",
                f"{risk_score}/100"
            )

        with metric2:
            st.metric(
                "Risk Status",
                risk_status
            )

        with metric3:
            st.metric(
                "Success Probability",
                f"{success_probability}%"
            )

        with metric4:
            st.metric(
                "Feasibility",
                f"{feasibility_score}%"
            )

        # Status message
        if risk_status == "HIGH RISK":
            st.error(
                "⚠️ High-risk project. Immediate mitigation "
                "of priority risks is recommended."
            )
        elif risk_status == "MEDIUM RISK":
            st.warning(
                "⚠️ Medium-risk project. Priority risks should "
                "be actively monitored and mitigated."
            )
        else:
            st.success(
                "✓ Low-risk project. Continue monitoring key "
                "project assumptions."
            )

        st.divider()

        # ========================================================
        # RISK FACTOR OVERVIEW
        # ========================================================

        st.subheader("Risk Factor Overview")

        if risk_data:

            risk_cols = st.columns(
                min(len(risk_data), 3)
            )

            for index, risk in enumerate(risk_data):

                with risk_cols[index % len(risk_cols)]:

                    category = risk.get(
                        "risk_category",
                        "Risk"
                    )

                    score = risk.get(
                        "risk_score",
                        0
                    )

                    description = risk.get(
                        "risk_description",
                        "No description available."
                    )

                    priority = risk.get(
                        "priority_level",
                        "Medium"
                    )

                    st.markdown(
                        f"""
                        <div style="
                            border: 1px solid #E5E7EB;
                            border-radius: 12px;
                            padding: 18px;
                            margin-bottom: 12px;
                            background: white;
                            min-height: 170px;
                        ">

                        <div style="
                            font-size: 15px;
                            color: #6B7280;
                            margin-bottom: 6px;
                        ">
                            {category} Risk
                        </div>

                        <div style="
                            font-size: 30px;
                            font-weight: 700;
                            color: #111827;
                        ">
                            {score}/100
                        </div>

                        <div style="
                            margin: 8px 0;
                            font-weight: 600;
                        ">
                            {priority} Priority
                        </div>

                        <div style="
                            color: #6B7280;
                            font-size: 14px;
                            line-height: 1.5;
                        ">
                            {description}
                        </div>

                        </div>
                        """,
                        unsafe_allow_html=True
                    )

        else:
            st.info("No detailed risk factors available.")

        # ========================================================
        # RISK VISUALIZATION
        # ========================================================

        if risk_data:

            st.markdown("### Risk Distribution")

            risk_chart = pd.DataFrame(
                {
                    "Risk Score": [
                        item.get("risk_score", 0)
                        for item in risk_data
                    ]
                },
                index=[
                    item.get(
                        "risk_category",
                        "Risk"
                    )
                    for item in risk_data
                ]
            )

            st.bar_chart(
                risk_chart,
                height=300
            )

        st.divider()

        # ========================================================
        # SWOT ANALYSIS
        # ========================================================

        st.subheader("SWOT Analysis")

        swot_col1, swot_col2 = st.columns(2)

        with swot_col1:

            st.success("### 💪 Strengths")

            strengths = swot.get(
                "Strengths",
                []
            )

            if strengths:
                for item in strengths:
                    st.markdown(f"- {item}")
            else:
                st.write("No strengths identified.")

            st.info("### 🚀 Opportunities")

            opportunities = swot.get(
                "Opportunities",
                []
            )

            if opportunities:
                for item in opportunities:
                    st.markdown(f"- {item}")
            else:
                st.write("No opportunities identified.")

        with swot_col2:

            st.error("### ⚠️ Weaknesses")

            weaknesses = swot.get(
                "Weaknesses",
                []
            )

            if weaknesses:
                for item in weaknesses:
                    st.markdown(f"- {item}")
            else:
                st.write("No weaknesses identified.")

            st.warning("### 🔥 Threats")

            threats = swot.get(
                "Threats",
                []
            )

            if threats:
                for item in threats:
                    st.markdown(f"- {item}")
            else:
                st.write("No threats identified.")

        st.divider()

        # ========================================================
        # FEASIBILITY
        # ========================================================

        st.subheader("Project Feasibility")

        feasibility_col1, feasibility_col2 = st.columns(
            [1, 2]
        )

        with feasibility_col1:

            st.metric(
                "Overall Feasibility",
                f"{feasibility_score}%"
            )

            if feasibility_score >= 70:
                st.success("Good Feasibility")
            elif feasibility_score >= 40:
                st.warning("Moderate Feasibility")
            else:
                st.error("Low Feasibility")

        with feasibility_col2:

            st.write("**Feasibility Components**")

            # These values come directly from the current
            # assessment inputs used to calculate feasibility.

            team_capability = st.session_state.get(
                "current_team_capability",
                None
            )

            competitive_advantage = st.session_state.get(
                "current_competitive_advantage",
                None
            )

            resource_score = st.session_state.get(
                "current_resource_score",
                None
            )

            market_opportunity = st.session_state.get(
                "current_market_opportunity",
                None
            )

            if team_capability is not None:
                st.progress(
                    team_capability / 100,
                    text=f"Team Capability — {team_capability}%"
                )

            if competitive_advantage is not None:
                st.progress(
                    competitive_advantage / 100,
                    text=(
                        "Competitive Advantage — "
                        f"{competitive_advantage}%"
                    )
                )

            if resource_score is not None:
                st.progress(
                    resource_score / 100,
                    text=(
                        "Resource Availability — "
                        f"{resource_score}%"
                    )
                )

            if market_opportunity is not None:
                st.progress(
                    market_opportunity / 100,
                    text=(
                        "Market Opportunity — "
                        f"{market_opportunity}%"
                    )
                )

        st.divider()

        # ========================================================
        # AI RECOMMENDATIONS
        # ========================================================

        st.subheader("AI Strategic Recommendations")

        if recommendations:

            overall_recommendation = recommendations.get(
                "overall_strategic_recommendation",
                ""
            )

            if overall_recommendation:
                st.info(
                    f"**Overall Strategic Recommendation**\n\n"
                    f"{overall_recommendation}"
                )

            recommendation_list = recommendations.get(
                "recommendations",
                []
            )

            if recommendation_list:

                for index, recommendation in enumerate(
                    recommendation_list,
                    start=1
                ):

                    title = recommendation.get(
                        "title",
                        f"Recommendation {index}"
                    )

                    category = recommendation.get(
                        "category",
                        "Strategy"
                    )

                    priority = recommendation.get(
                        "priority",
                        "Medium"
                    )

                    action = recommendation.get(
                        "action",
                        "N/A"
                    )

                    problem = recommendation.get(
                        "problem",
                        ""
                    )

                    explanation = recommendation.get(
                        "explanation",
                        ""
                    )

                    risk_reduction = recommendation.get(
                        "risk_reduction",
                        ""
                    )

                    with st.expander(
                        f"{index}. {title} — {priority} Priority"
                    ):

                        st.markdown(
                            f"**Category:** {category}"
                        )

                        if problem:
                            st.markdown(
                                f"**Problem / Risk:** {problem}"
                            )

                        if explanation:
                            st.markdown(
                                f"**Why It Matters:** {explanation}"
                            )

                        st.markdown(
                            f"**Recommended Action:** {action}"
                        )

                        if risk_reduction:
                            st.markdown(
                                f"**Risk Reduction:** "
                                f"{risk_reduction}"
                            )

            short_term = recommendations.get(
                "short_term_action_plan",
                []
            )

            long_term = recommendations.get(
                "long_term_action_plan",
                []
            )

            if short_term:

                st.markdown("### Short-Term Action Plan")

                for action in short_term:
                    st.markdown(
                        f"- {action}"
                    )

            if long_term:

                st.markdown("### Long-Term Action Plan")

                for action in long_term:
                    st.markdown(
                        f"- {action}"
                    )

        else:
            st.info(
                "No strategic recommendations are currently available."
            )

        st.divider()

        # ========================================================
        # MITIGATION STRATEGIES
        # ========================================================

        st.subheader("Risk Mitigation Strategies")

        if mitigation_results:

            for mitigation in mitigation_results:

                risk_name = mitigation.get(
                    "risk",
                    "Unknown Risk"
                )

                category = mitigation.get(
                    "category",
                    "General"
                )

                impact = mitigation.get(
                    "impact",
                    "Unknown"
                )

                strategy = mitigation.get(
                    "mitigation_strategy",
                    "N/A"
                )

                preventive = mitigation.get(
                    "preventive_action",
                    "N/A"
                )

                contingency = mitigation.get(
                    "contingency_action",
                    "N/A"
                )

                with st.expander(
                    f"⚠️ {risk_name} — {impact} Impact"
                ):

                    st.markdown(
                        f"**Category:** {category}"
                    )

                    st.markdown(
                        f"**Mitigation Strategy:** {strategy}"
                    )

                    st.markdown(
                        f"**Preventive Action:** {preventive}"
                    )

                    st.markdown(
                        f"**Contingency Action:** {contingency}"
                    )

        else:
            st.info(
                "No mitigation strategies are currently available."
            )

        st.divider()

        # ========================================================
        # IMPROVEMENT PLAN
        # ========================================================

        st.subheader("Project Improvement Plan")

        if improvement_results:

            improvement_cols = st.columns(3)

            for index, improvement in enumerate(
                improvement_results
            ):

                with improvement_cols[
                    index % 3
                ]:

                    title = improvement.get(
                        "title",
                        "Improvement"
                    )

                    category = improvement.get(
                        "category",
                        "General"
                    )

                    priority = improvement.get(
                        "priority",
                        "Medium"
                    )

                    problem = improvement.get(
                        "problem",
                        ""
                    )

                    steps = improvement.get(
                        "steps",
                        []
                    )

                    risk_reduction = improvement.get(
                        "risk_reduction",
                        ""
                    )

                    st.markdown(
                        f"""
                        <div style="
                            border: 1px solid #E5E7EB;
                            border-radius: 12px;
                            padding: 18px;
                            margin-bottom: 16px;
                            min-height: 230px;
                            background: white;
                        ">

                        <div style="
                            color: #6D28D9;
                            font-size: 13px;
                            font-weight: 700;
                            text-transform: uppercase;
                        ">
                            {category}
                        </div>

                        <h4 style="
                            margin: 8px 0;
                            color: #111827;
                        ">
                            {title}
                        </h4>

                        <div style="
                            color: #6B7280;
                            font-size: 14px;
                        ">
                            Priority: <b>{priority}</b>
                        </div>

                        </div>
                        """,
                        unsafe_allow_html=True
                    )

                    if problem:
                        st.markdown(
                            f"**Problem:** {problem}"
                        )

                    if steps:

                        st.markdown("**Action Steps:**")

                        for step in steps:
                            st.markdown(
                                f"- {step}"
                            )

                    if risk_reduction:
                        st.markdown(
                            f"**Expected Risk Reduction:** "
                            f"{risk_reduction}"
                        )

        else:
            st.info(
                "No improvement suggestions are currently available."
            )

        st.divider()

        # ========================================================
        # LANGGRAPH FINAL ASSESSMENT
        # ========================================================

        st.subheader("Final Strategic Assessment")

        if final_response:

            assessment_text = final_response.get(
                "final_strategic_assessment",
                ""
            )

            if assessment_text:
                st.info(
                    assessment_text
                )

            final_summary = final_response.get(
                "project_summary",
                {}
            )

            if final_summary:

                with st.expander(
                    "View Final Project Summary"
                ):

                    st.write(
                        f"**Project:** "
                        f"{final_summary.get('project_name', 'N/A')}"
                    )

                    st.write(
                        f"**Industry:** "
                        f"{final_summary.get('industry', 'N/A')}"
                    )

                    st.write(
                        f"**Business Model:** "
                        f"{final_summary.get('business_model', 'N/A')}"
                    )

                    st.write(
                        f"**Target Market:** "
                        f"{final_summary.get('target_market', 'N/A')}"
                    )

        else:

            st.info(
                "Run the LangGraph Agent Workflow in the "
                "Recommendations tab to generate the final strategic assessment."
            )

        st.divider()

        # ========================================================
        # EXPORT REPORT
        # ========================================================

        st.subheader("Export Assessment")

        report_lines = []

        report_lines.append(
            "# Prediction AI - Project Risk Assessment"
        )

        report_lines.append("")

        report_lines.append(
            f"Project: {project.get('startup_name', 'N/A')}"
        )

        report_lines.append(
            f"Industry: {project.get('industry', 'N/A')}"
        )

        report_lines.append(
            f"Business Model: {project.get('business_model', 'N/A')}"
        )

        report_lines.append(
            f"Target Market: {project.get('target_market', 'N/A')}"
        )

        report_lines.append("")

        report_lines.append("## Risk Summary")

        report_lines.append(
            f"- Risk Score: {risk_score}/100"
        )

        report_lines.append(
            f"- Risk Status: {risk_status}"
        )

        report_lines.append(
            f"- Success Probability: {success_probability}%"
        )

        report_lines.append(
            f"- Feasibility Score: {feasibility_score}%"
        )

        report_lines.append("")

        report_lines.append("## SWOT")

        for section in [
            "Strengths",
            "Weaknesses",
            "Opportunities",
            "Threats"
        ]:

            report_lines.append(
                f"### {section}"
            )

            for item in swot.get(section, []):
                report_lines.append(
                    f"- {item}"
                )

        report_lines.append("")

        report_lines.append("## Strategic Recommendations")

        for recommendation in recommendations.get(
            "recommendations",
            []
        ):

            report_lines.append(
                f"- {recommendation.get('title', 'Recommendation')}: "
                f"{recommendation.get('action', 'N/A')}"
            )

        report_lines.append("")

        report_lines.append("## Mitigation Strategies")

        for mitigation in mitigation_results:

            report_lines.append(
                f"- {mitigation.get('risk', 'Risk')}: "
                f"{mitigation.get('mitigation_strategy', 'N/A')}"
            )

        report_lines.append("")

        report_lines.append("## Improvement Plan")

        for improvement in improvement_results:

            report_lines.append(
                f"- {improvement.get('title', 'Improvement')} "
                f"({improvement.get('priority', 'Medium')})"
            )

        report_content = "\n".join(
            report_lines
        )

        st.download_button(
            label="📥 Download Assessment Report",
            data=report_content,
            file_name="project_risk_assessment.md",
            mime="text/markdown",
            use_container_width=True
        )

